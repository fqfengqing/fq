import time
import json
import os
import sys
import csv
from threading import Thread

import requests



from wx_sdk import WeChatPublicManager


def add_draft(appid, appsecret, thumb_media_id):
    wx_public = WeChatPublicManager(appid, appsecret)
    with open(r'{}'.format(input("请输入csv文件路径: ")), 'r', encoding='gbk') as f:
        reader = csv.reader(f)

        # 遍历每一行
        for row in reader:
            # 输出第一列的内容
            content = row[0]
            name = content[:20]
            thumb_media_id = thumb_media_id

            content_length = len(content)
            if content_length >= 20000:
                print(f"{name} 内容字数过多，超过2万字符, {len(content)}")
                continue
            try:
                formatted_content = """"""

                # for image_dict in obj.images:
                #     image_path = image_dict.get("head_1", "")
                #     image_file_path = os.path.join(settings.MEDIA_ROOT, image_path)
                #     context_url = upload_image_text(access_token,
                #                                     r'D:/project_common/wx_official_accounts/wx_platform_web/media/' + image_path)
                #     main_thumb_media = add_permanent_material(access_token,
                #                                               r'D:/project_common/wx_official_accounts/wx_platform_web/media/' + image_path)
                #     thumb_media_id = main_thumb_media["media_id"]
                #
                #     formatted_content += f'''<p>
                #         <img src="{context_url}" alt="{obj.medicine_name}" style="width: 100%; height: auto;" />
                #             <br />
                #         </p>
                #     '''

                # print(thumb_media_id)
                content_list = content.split("\n")
                content_list = [i.strip() for i in content_list]

                for paragraph in content_list:
                    formatted_content += f'<p style="font-size: 16px;">{paragraph}</p>'

                articles = [
                    {
                        "title": f'{name} - {"我的合集"}',
                        "author": "fq",
                        "digest": f'{content[:100] if content else ""}',
                        "content": formatted_content,
                        "thumb_media_id": thumb_media_id,
                        "need_open_comment": 1,  # Uint32 是否打开评论，0不打开(默认)，1打开
                        "only_fans_can_comment": 1,  # Uint32 是否粉丝才可评论，0所有人可评论(默认)，1粉丝才可评论
                        # "pic_crop_235_1": "0.1945_0_1_0.5236",
                        # "pic_crop_1_1": "0.1_0_0.9_0.9"
                        # "content_source_url": "http://example.com",

                    }
                ]

                media_id = wx_public.add_draft(articles)
                if media_id != None:
                    # 更新上传状态
                    print(f"Uploaded prescription '{name}' with media_id: {media_id}")
                else:
                    time.sleep(0.25)
                    print(f"Failed to upload prescription '{name}'")

            except Exception as e:
                print(f"Failed to upload prescription '{name}': {e}")
            break

def main(appid, appsecret):
    while True:
        try:
            operator_number = int(input("请输入操作 (1, '发布草稿') "
                                        "(2, '发布文章') "
                                        "(3, '同时发布') "
                                        "(4, '上传永久素材') "
                                        ": "))
            if operator_number == 1:
                # lRaPD8T-jqdq_2CoO976i7lCa8R-k7Gm5KxMxykYpctCEaIxulSnjUjIe3UF66P3
                add_draft(appid, appsecret, input("请输入media_id: "))
            elif operator_number == 2:
                wx_public = WeChatPublicManager(appid, appsecret)
                wx_public.batch_publish_drafts()
            elif operator_number == 3:
                wx_public = WeChatPublicManager(appid, appsecret)

                t1 = Thread(target=add_draft, args=(appid, appsecret))
                t2 = Thread(target=wx_public.batch_publish_drafts)

                t1.start()
                t2.start()

                t1.join()
                t2.join()

            elif operator_number == 4:
                """上传永久素材"""
                wx_public = WeChatPublicManager(appid, appsecret)
                wx_public.upload_permanent_material(r'{}'.format(input("请输入图片路径: ")), 'image')

        except ValueError:
            print("请输入正确指令")

        break


if __name__ == '__main__':
    appid = "wx724ec12c6371440f" # fq
    appsecret = "61ebcc19d568e5a1e7bdc0bf8aaf7370"
    main(appid, appsecret)  # 添加草稿

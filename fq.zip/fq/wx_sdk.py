import json
import requests
import time
from datetime import datetime


class WeChatPublicManager:
    def __init__(self, appid, appsecret):
        self.appid = appid
        self.appsecret = appsecret
        self.access_token = None
        self.get_token()

    def check_response_code(self, data):
        """
        检查微信公众平台 API 的返回码并打印错误信息

        :param response: 接口返回的 response 对象
        """
        try:

            errcode = data.get("errcode", 0)
            errmsg = data.get("errmsg", "未知错误")

            # 状态码处理
            if errcode == -1:
                print(f"系统繁忙，此时请开发者稍候再试 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 0:
                print("请求成功")
            elif errcode == 40001:
                print(f"获取 access_token 时 AppSecret 错误，或者 access_token 无效 (errcode: {errcode}, errmsg: {errmsg})")
                self.get_token()
            elif errcode == 40002:
                print(f"不合法的凭证类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40003:
                print(f"不合法的 OpenID (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40004:
                print(f"不合法的媒体文件类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40005:
                print(f"不合法的文件类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40006:
                print(f"不合法的文件大小 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40007:
                print(f"不合法的媒体文件 id (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40008:
                print(f"不合法的消息类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40009:
                print(f"不合法的图片文件大小 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40010:
                print(f"不合法的语音文件大小 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40011:
                print(f"不合法的视频文件大小 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40012:
                print(f"不合法的缩略图文件大小 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40013:
                print(f"不合法的 AppID (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40014:
                print(f"不合法的 access_token (errcode: {errcode}, errmsg: {errmsg})")
                self.get_token()
            elif errcode == 40015:
                print(f"不合法的菜单类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40016:
                print(f"不合法的按钮个数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40017:
                print(f"不合法的按钮类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40018:
                print(f"不合法的按钮名字长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40019:
                print(f"不合法的按钮 KEY 长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40020:
                print(f"不合法的按钮 URL 长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40021:
                print(f"不合法的菜单版本号 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40022:
                print(f"不合法的子菜单级数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40023:
                print(f"不合法的子菜单按钮个数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40024:
                print(f"不合法的子菜单按钮类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40025:
                print(f"不合法的子菜单按钮名字长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40026:
                print(f"不合法的子菜单按钮 KEY 长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40027:
                print(f"不合法的子菜单按钮 URL 长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40028:
                print(f"不合法的自定义菜单使用用户 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40029:
                print(f"无效的 oauth_code (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40030:
                print(f"不合法的 refresh_token (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40031:
                print(f"不合法的 openid 列表 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40032:
                print(f"不合法的 openid 列表长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40033:
                print(f"不合法的请求字符，不能包含 \\uxxxx 格式的字符 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40035:
                print(f"不合法的参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40038:
                print(f"不合法的请求格式 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40039:
                print(f"不合法的 URL 长度 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40048:
                print(f"无效的url (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40050:
                print(f"不合法的分组 id (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40051:
                print(f"分组名字不合法 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40060:
                print(f"删除单篇图文时，指定的 article_idx 不合法 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40117:
                print(f"分组名字不合法 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40118:
                print(f"media_id 大小不合法 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40119:
                print(f"button 类型错误 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40120:
                print(f"子 button 类型错误 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40121:
                print(f"不合法的 media_id 类型 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40125:
                print(f"无效的appsecret (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40132:
                print(f"微信号不合法 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40137:
                print(f"不支持的图片格式 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40155:
                print(f"请勿添加其他公众号的主页链接 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40163:
                print(f"oauth_code已使用 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40227:
                print(f"标题为空 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40243:
                print(f"AppSecret已被冻结，请登录MP解冻后再次调用 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40249:
                print(f"不支持下发营销/推广类的消息内容 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40250:
                print(
                    f"下发消息内容不规范（包含空值等），建议检查内容规范性后再下发 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40251:
                print(f"因历史违规导致平台限制账号调用上限，当前已到达下发上限 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 40252:
                print(
                    f"正在调用的模板下发的部分内容已进入平台审核流程，在审核完成前，相关内容暂时无法下发 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41001:
                print(f"缺少 access_token 参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41002:
                print(f"缺少 appid 参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41003:
                print(f"缺少 refresh_token 参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41004:
                print(f"缺少 secret 参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41005:
                print(f"缺少多媒体文件数据 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41006:
                print(f"缺少 media_id 参数 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41007:
                print(f"缺少子菜单数据 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41008:
                print(f"缺少 oauth code (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 41009:
                print(f"缺少 openid (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 42001:
                print(f"{datetime.now()} access_token 超时，请检查 access_token 的有效期 (errcode: {errcode}, errmsg: {errmsg})")
                self.get_token()
            elif errcode == 42002:
                print(f"refresh_token 超时 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 42003:
                print(f"oauth_code 超时 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 42007:
                print(
                    f"用户修改微信密码， accesstoken 和 refreshtoken 失效，需要重新授权 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 42010:
                print(f"相同 media_id 群发过快，请重试 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43001:
                print(f"需要 GET 请求 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43002:
                print(f"需要 POST 请求 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43003:
                print(f"需要 HTTPS 请求 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43004:
                print(f"需要接收者关注 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43005:
                print(f"需要好友关系 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43019:
                print(f"需要将接收者从黑名单中移除 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 43116:
                print(f"该模板因滥用被滥用过多，已被限制下发 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44001:
                print(f"多媒体文件为空 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44002:
                print(f"POST 的数据包为空 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44003:
                print(f"图文消息内容为空 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44004:
                print(f"文本消息内容为空 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44008:
                print(f"音频内容审核失败 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 44009:
                print(f"图文中的音频内容审核失败 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45001:
                print(f"多媒体文件大小超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45002:
                print(f"消息内容超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45003:
                print(f"标题字段超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45004:
                print(f"描述字段超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45005:
                print(f"链接字段超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45006:
                print(f"图片链接字段超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45007:
                print(f"语音播放时间超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45008:
                print(f"图文消息超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45009:
                print(f"接口调用超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45010:
                print(f"创建菜单个数超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45011:
                print(f"API 调用太频繁，请稍候再试 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45015:
                print(f"回复时间超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45016:
                print(f"系统分组，不允许修改 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45017:
                print(f"分组名字过长 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45018:
                print(f"分组数量超过上限 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45047:
                print(f"客服接口下行条数超过上限 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45064:
                print(f"创建菜单包含未关联的小程序 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45065:
                print(
                    f"相同 clientmsgid 已存在群发记录，返回数据中带有已存在的群发任务的 msgid (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45066:
                print(f"相同 clientmsgid 重试速度过快，请间隔1分钟重试 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45067:
                print(f"clientmsgid 长度超过限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 45110:
                print(f"作者字数超出限制 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 46001:
                print(f"不存在媒体数据 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 46002:
                print(f"不存在的菜单版本 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 46003:
                print(f"不存在的菜单数据 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 46004:
                print(f"不存在的用户 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 47001:
                print(f"解析 JSON/XML 内容错误 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 47003:
                print(f"参数值不符合限制要求，详情可参考参数值内容限制说明 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 48001:
                print(f"api 功能未授权，请确认公众号已获得该接口 (errcode: {errcode}, errmsg: {errmsg})")
            elif errcode == 48002:
                print(f"粉丝拒收消息（粉丝在公众号选项中，关闭了 “ 接收消息 ” ）")
            elif errcode == 53501:
                print(f"频繁请求发布 53501")
                time.sleep(1)

        except Exception as e:
            print(e)

    def get_token(self, force_refresh=False, retries=3, delay=2):
        # 准备请求数据
        payload = {
            "grant_type": "client_credential",
            "appid": self.appid,
            "secret": self.appsecret
        }

        if force_refresh:
            payload["force_refresh"] = True

        for attempt in range(retries):
            try:
                # 发送POST请求
                response = requests.post("https://api.weixin.qq.com/cgi-bin/stable_token", json=payload)

                # 处理响应
                if response.status_code == 200:
                    data = response.json()
                    print(data, "获取token 返回体")
                    if "access_token" in data:
                        self.access_token = data["access_token"]
                        return self.access_token
                    else:
                        error_code = data.get("errcode", "未知错误")
                        print(f"获取access token时出错: {error_code}")
                        return None
                else:
                    print(f"连接微信API失败，状态码: {response.status_code}")
                    return None

            except requests.exceptions.RequestException as e:
                print(f"请求失败: {e}, 尝试第 {attempt + 1} 次重试...")
                time.sleep(delay)  # 等待一段时间后重试

        print("所有重试均失败，无法获取access token")
        return None

    def clear_wechat_quota(self, retries=3, delay=2):
        if not self.access_token:
            print("请先获取access token。")
            return False

        # 请求的URL
        url = f"https://api.weixin.qq.com/cgi-bin/clear_quota?access_token={self.access_token}"

        # 准备请求数据
        payload = {
            "appid": self.appid
        }

        for attempt in range(retries):
            try:
                # 发送POST请求
                response = requests.post(url, json=payload, timeout=10)

                # 处理响应
                if response.status_code == 200:
                    data = response.json()
                    if data['errcode'] == 0:
                        print("清空配额成功")
                        return True
                    else:
                        print(f"清空配额失败: {data['errmsg']} (错误码: {data['errcode']})")
                        return False
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return False

            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)  # 等待一段时间后重试

        print("所有重试均失败，无法获取清空配额的结果。")
        return False

    def query_api_quota(self, cgi_path, retries=3, delay=2):
        if not self.access_token:
            print("请先获取access token。")
            return None

        # 请求的URL
        url = f"https://api.weixin.qq.com/cgi-bin/openapi/quota/get?access_token={self.access_token}"

        # 准备请求数据
        payload = {
            "cgi_path": cgi_path
        }

        for attempt in range(retries):
            try:
                # 发送POST请求
                response = requests.post(url, json=payload, timeout=10)

                # 处理响应
                if response.status_code == 200:
                    data = response.json()
                    if data['errcode'] == 0:
                        print("查询配额成功:", data['quota'])
                        return data['quota']
                    else:
                        print(f"查询配额失败: {data['errmsg']} (错误码: {data['errcode']})")
                        return None
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return None

            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)  # 等待一段时间后重试

        print("所有重试均失败，无法获取API调用配额的结果。")
        return None

    def query_rid_info(self, rid, retries=3, delay=2):
        if not self.access_token:
            print("请先获取access token。")
            return None

        url = f"https://api.weixin.qq.com/cgi-bin/openapi/rid/get?access_token={self.access_token}"
        payload = {
            "rid": rid
        }

        for attempt in range(retries):
            try:
                response = requests.post(url, json=payload, timeout=10)

                if response.status_code == 200:
                    data = response.json()
                    if data['errcode'] == 0:
                        print("查询RID信息成功:", data['request'])
                        return data['request']
                    else:
                        print(f"查询RID信息失败: {data['errmsg']} (错误码: {data['errcode']})")
                        return None
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return None

            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法获取RID信息的结果。")
        return None

    def clear_quota_by_appsecret(self, retries=3, delay=2):
        url = f"https://api.weixin.qq.com/cgi-bin/clear_quota/v2?appid={self.appid}&appsecret={self.appsecret}"

        for attempt in range(retries):
            try:
                response = requests.post(url)

                if response.status_code == 200:
                    data = response.json()
                    if data['errcode'] == 0:
                        print("清空配额成功")
                        return True
                    else:
                        print(f"清空配额失败: {data['errmsg']} (错误码: {data['errcode']})")
                        return False
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return False

            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法清空配额。")
        return False

    def upload_temp_media(self, media_file_path, media_type, retries=3, delay=2):
        """
        上传临时素材到微信服务器

        :param media_file_path: 媒体文件的路径
        :param media_type: 媒体文件类型，支持'image', 'voice', 'video', 'thumb'
        :param retries: 最大重试次数
        :param delay: 每次重试之间的延迟时间（秒）
        :return: 返回上传成功的媒体信息或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/media/upload?access_token={self.access_token}&type={media_type}"

        for attempt in range(retries):
            try:
                # 使用FORM表单方式上传文件
                with open(media_file_path, 'rb') as media_file:
                    files = {'media': media_file}
                    response = requests.post(url, files=files)

                if response.status_code == 200:
                    data = response.json()
                    if 'media_id' in data:
                        print("上传成功:", data)
                        return data
                    else:
                        print(f"上传失败: {data['errmsg']} (错误码: {data['errcode']})")
                        return None
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return None

            except FileNotFoundError:
                print(f"文件未找到: {media_file_path}")
                return None
            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法上传临时素材。")
        return None

    def get_temp_media(self, media_id, retries=3, delay=2):
        """
        获取临时素材

        :param media_id: 媒体文件ID
        :param retries: 最大重试次数
        :param delay: 每次重试之间的延迟时间（秒）
        :return: 返回下载的文件内容或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/media/get?access_token={self.access_token}&media_id={media_id}"

        for attempt in range(retries):
            try:
                # 发送GET请求
                response = requests.get(url)

                if response.status_code == 200:
                    # 检查Content-Type以确定返回的媒体类型
                    content_type = response.headers.get('Content-Type')
                    if 'video' in content_type:
                        # 处理视频类型的返回
                        return response.json()  # 返回视频URL
                    else:
                        # 保存文件到本地
                        filename = f"{media_id}.{content_type.split('/')[-1]}"
                        with open(filename, 'wb') as file:
                            file.write(response.content)
                        print(f"下载成功，文件保存为: {filename}")
                        return filename
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return None

            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法获取临时素材。")
        return None

    def upload_permanent_material(self, media_file_path, media_type, video_title=None, video_introduction=None,
                                  retries=3, delay=2):
        """
        上传永久素材到微信服务器

        :param media_file_path: 媒体文件的路径
        :param media_type: 媒体文件类型，支持'image', 'voice', 'video', 'thumb'
        :param video_title: 视频素材的标题（仅在上传视频时使用）
        :param video_introduction: 视频素材的描述（仅在上传视频时使用）
        :param retries: 最大重试次数
        :param delay: 每次重试之间的延迟时间（秒）
        :return: 返回上传成功的媒体信息或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/material/add_material?access_token={self.access_token}&type={media_type}"

        for attempt in range(retries):
            try:
                # 准备文件上传
                with open(media_file_path, 'rb') as media_file:
                    files = {'media': media_file}

                    # 如果是视频类型，添加视频描述
                    if media_type == 'video':
                        description = {
                            "title": video_title,
                            "introduction": video_introduction
                        }
                        files['description'] = (None, str(description).replace("'", '"'))  # 转换为JSON格式

                    # 发送POST请求
                    response = requests.post(url, files=files)

                    if response.status_code == 200:
                        data = response.json()
                        if 'media_id' in data:
                            print("上传成功:", data)
                            return data
                        else:
                            print(f"上传失败: {data['errmsg']} (错误码: {data['errcode']})")
                            return None
                    else:
                        print(f"请求失败，状态码: {response.status_code}")
                        return None

            except FileNotFoundError:
                print(f"文件未找到: {media_file_path}")
                return None
            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法上传永久素材。")
        return None

    def upload_image_for_article(self, image_file_path, retries=3, delay=2):
        """
        上传图文消息内的图片并获取URL

        :param image_file_path: 图片文件的路径
        :param retries: 最大重试次数
        :param delay: 每次重试之间的延迟时间（秒）
        :return: 返回上传成功的图片URL或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token={self.access_token}"

        for attempt in range(retries):
            try:
                # 准备文件上传
                with open(image_file_path, 'rb') as image_file:
                    files = {'media': image_file}

                    # 发送POST请求
                    response = requests.post(url, files=files)

                    if response.status_code == 200:
                        data = response.json()
                        if 'url' in data:
                            print("上传成功:", data)
                            return data['url']
                        else:
                            print(f"上传失败: {data['errmsg']} (错误码: {data['errcode']})")
                            return None
                    else:
                        print(f"请求失败，状态码: {response.status_code}")
                        return None

            except FileNotFoundError:
                print(f"文件未找到: {image_file_path}")
                return None
            except requests.ConnectionError:
                print("连接错误，请检查网络连接。")
            except requests.Timeout:
                print("请求超时，请稍后重试。")
            except requests.RequestException as e:
                print(f"发生错误: {e}")

            print(f"正在重试，当前为第 {attempt + 1} 次尝试...")
            time.sleep(delay)

        print("所有重试均失败，无法上传图文消息内的图片。")
        return None

    def get_permanent_material(self, media_id):
        """
        获取永久素材

        :param access_token: 调用接口凭证
        :param media_id: 要获取的素材的media_id
        :return: 返回获取的素材内容
        """
        url = "https://api.weixin.qq.com/cgi-bin/material/get_material?access_token={}".format(self.access_token)

        payload = {
            "media_id": media_id
        }

        response = requests.post(url, json=payload)

        if response.status_code == 200:
            # 获取Content-disposition响应头
            content_disposition = response.headers.get('Content-disposition')

            if content_disposition:
                # 从Content-disposition中解析出文件名
                filename = content_disposition.split('filename="')[1][:-1]

                # 保存素材到文件
                with open(filename, "wb") as f:
                    f.write(response.content)

                print(f"素材已保存到文件: {filename}")
                return filename
            else:
                # 判断是否为JSON数据
                content_type = response.headers.get('Content-Type')
                if 'application/json' in content_type:
                    data = response.json()
                    if 'news_item' in data:
                        return data['news_item']
                    elif 'down_url' in data:
                        return data
                    else:
                        return data
                else:
                    return response.content
        else:
            print("获取永久素材失败, 错误码: {}".format(response.status_code))
            return None

    def delete_permanent_material(self, media_id):
        """
        删除永久素材

        :param media_id: 要删除的素材的media_id
        :return: 返回删除结果的状态和信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/material/del_material?access_token={self.access_token}"

        payload = {
            "media_id": media_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                if data['errcode'] == 0:
                    print("删除永久素材成功")
                    return True
                else:
                    print(f"删除永久素材失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return False
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return False

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return False

    def get_material_count(self):
        """
        获取永久素材的总数

        :param access_token: 调用接口凭证
        :return: 返回永久素材的总数或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/material/get_materialcount?access_token={self.access_token}"

        try:
            response = requests.get(url)

            if response.status_code == 200:
                data = response.json()
                print(data)
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    return data
                else:
                    print(f"获取素材总数失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def get_material_list(self, material_type, offset=0, count=20):
        """
        获取永久素材列表

        :param access_token: 调用接口凭证
        :param material_type: 素材类型，支持'image', 'video', 'voice', 'news'
        :param offset: 从该偏移位置开始返回，0表示从第一个素材返回
        :param count: 返回素材的数量，取值在1到20之间
        :return: 返回永久素材的列表或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "type": material_type,
            "offset": offset,
            "count": count
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                response.encoding = "utf-8"
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    return data  # 返回素材列表
                else:
                    print(f"获取素材列表失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def add_draft(self, articles):
        """
        新增草稿到草稿箱

        :param access_token: 调用接口凭证
        :param articles: 草稿文章列表，每个文章为字典格式
        :return: 返回上传后的媒体ID或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/add?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "articles": articles
        }

        try:
            response = requests.post(url, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"))

            if response.status_code == 200:
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("media_id"):
                    print("草稿新增成功，媒体ID:", data['media_id'])
                    return data['media_id']  # 返回媒体ID
                else:
                    print(f"新增草稿失败: {data['errmsg']} (错误码: {data['errcode']})")
                    self.check_response_code(data)
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def get_draft(self, media_id):
        """
        获取指定的草稿

        :param access_token: 调用接口凭证
        :param media_id: 要获取的草稿的media_id
        :return: 返回草稿内容或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/get?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "media_id": media_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    return data  # 返回草稿内容
                else:
                    print(f"获取草稿失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def delete_draft(self, media_id):
        """
        删除指定的草稿

        :param media_id: 要删除的草稿的media_id
        :return: 返回删除结果的状态和信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/delete?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "media_id": media_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    print("删除草稿成功")
                    return True
                else:
                    print(f"删除草稿失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return False
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return False

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return False

    def update_draft(self, media_id, index, article):
        """
        修改指定的草稿

        :param media_id: 要修改的图文消息的id
        :param index: 要更新的文章在图文消息中的位置
        :param article: 要更新的文章内容，字典格式
        :return: 返回修改结果的状态和信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/update?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "media_id": media_id,
            "index": index,
            "articles": article
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    print("草稿修改成功")
                    return True
                else:
                    print(f"修改草稿失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return False
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return False

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return False

    def get_draft_count(self):
        """
        获取草稿的总数

        :param access_token: 调用接口凭证
        :return: 返回草稿的总数或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/count?access_token={self.access_token}"

        try:
            response = requests.get(url)

            if response.status_code == 200:
                data = response.json()
                # 检查返回的数据中是否包含total_count
                if "total_count" in data:
                    return data["total_count"]  # 返回草稿总数
                else:
                    print(f"获取草稿总数失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def get_draft_list(self, offset=0, count=20, no_content=0):
        """
        获取草稿列表

        :param access_token: 调用接口凭证
        :param offset: 从该偏移位置开始返回，0表示从第一个素材返回
        :param count: 返回素材的数量，取值在1到20之间
        :param no_content: 1表示不返回 content 字段，0表示正常返回，默认为0
        :return: 返回草稿列表或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "offset": offset,
            "count": count,
            "no_content": no_content
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                response.encoding = "utf-8"
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode", 0) == 0:
                    return data  # 返回草稿列表
                else:
                    print(f"获取草稿列表失败: {data['errmsg']} (错误码: {data['errcode']})")
                    self.check_response_code(data)
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def publish_draft(self, media_id):
        """
        发布指定的草稿

        :param media_id: 要发布的草稿的media_id
        :return: 返回发布结果的状态和信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "media_id": media_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                response.encoding = "utf-8"
                data = response.json()
                # 检查errcode是否为0，表示发布成功
                if data.get("errcode", 0) == 0:
                    print(f"{datetime.now()} 发布成功, 发布任务ID:", data['publish_id'])
                    return data
                else:
                    print(f"发布失败: {data['errmsg']} (错误码: {data['errcode']})")
                    self.check_response_code(data)
                    return data
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def get_publish_status(self, publish_id):
        """
        获取发布状态

        :param access_token: 调用接口凭证
        :param publish_id: 发布任务id
        :return: 返回发布状态或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/get?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "publish_id": publish_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查返回的状态
                if "publish_status" in data:
                    return data  # 返回发布状态信息
                else:
                    print(f"获取发布状态失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def delete_published_article(self, article_id, index=0):
        """
        删除已发布的文章

        :param access_token: 调用接口凭证
        :param article_id: 成功发布时返回的 article_id
        :param index: 要删除的文章在图文消息中的位置，第一篇编号为1，0表示删除全部文章
        :return: 返回删除结果的状态和信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/delete?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "article_id": article_id,
            "index": index
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查errcode是否为0，表示成功
                if data.get("errcode") == 0:
                    print("删除成功")
                    return True
                else:
                    print(f"删除失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return False
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return False

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return False

    def get_published_article(self, article_id):
        """
        获取已发布的图文信息

        :param access_token: 调用接口凭证
        :param article_id: 要获取的文章的article_id
        :return: 返回文章信息或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/getarticle?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "article_id": article_id
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                data = response.json()
                # 检查返回的数据中是否包含新闻项
                if "news_item" in data:
                    return data  # 返回文章信息
                else:
                    print(f"获取文章信息失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def get_successful_publish_list(self, offset=0, count=20, no_content=0):
        """
        获取已成功发布的消息列表

        :param access_token: 调用接口凭证
        :param offset: 从该偏移位置开始返回，0表示从第一个素材返回
        :param count: 返回素材的数量，取值在1到20之间
        :param no_content: 1表示不返回 content 字段，0表示正常返回，默认为0
        :return: 返回成功发布的消息列表或错误信息
        """
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token={self.access_token}"

        # 构建请求payload
        payload = {
            "offset": offset,
            "count": count,
            "no_content": no_content
        }

        try:
            response = requests.post(url, json=payload)

            if response.status_code == 200:
                response.encoding = 'utf-8'
                data = response.json()
                # 检查返回的数据中是否包含成功发布的消息
                if "item" in data:
                    return data  # 返回成功发布的消息列表
                else:
                    print(f"获取成功发布列表失败: {data['errmsg']} (错误码: {data['errcode']})")
                    return None
            else:
                print(f"请求失败，状态码: {response.status_code}")
                return None

        except requests.ConnectionError:
            print("连接错误，请检查网络连接。")
        except requests.Timeout:
            print("请求超时，请稍后重试。")
        except requests.RequestException as e:
            print(f"发生错误: {e}")

        return None

    def batch_publish_drafts(self):
        """
        批量发布草稿
        """
        count_per_page = 20  # 每页获取的草稿数量

        draft_items = self.get_draft_list(count=count_per_page, no_content=1)
        if draft_items is None:
            print("获取草稿列表失败，无法进行发布。")
            return  # 处理获取草稿失败的情况

        total_count = draft_items.get("total_count", 0)
        pages = (total_count + count_per_page - 1) // count_per_page  # 计算总页数

        for page in range(pages):
            offset = page * count_per_page  # 计算当前页的偏移量
            draft_items = self.get_draft_list(offset=offset, count=count_per_page, no_content=1)

            if draft_items is None:
                print("获取草稿列表失败，无法进行发布。")
                return  # 处理获取草稿失败的情况

            for draft in draft_items.get("item", []):
                media_id = draft["media_id"]
                result = self.publish_draft(media_id)
                if result and result.get("errcode") == 45009:
                    # 如果返回45009，调用配额查询
                    self.clear_wechat_quota()
                print(f"开始延时。。。{datetime.now()}")
                time.sleep(61)
                print(f"结束延时。。。{datetime.now()}")


if __name__ == "__main__":
    appid = ""  # 替换为实际的appid
    appsecret = ""  # 替换为实际的appsecret

    wechat_manager = WeChatPublicManager(appid, appsecret)
    access_token = wechat_manager.get_token()  # 获取access token
    # if access_token:
    #     wechat_manager.clear_wechat_quota()  # 清空API调用配额

    # wechat_manager.query_api_quota("/cgi-bin/freepublish/submit", retries=3, delay=2)
    # wechat_manager.clear_quota_by_appsecret()
    # wechat_manager.query_rid_info("66d14775-2c62ef6a-060c85d6")
    # wechat_manager.upload_temp_media(r'changqiang.jpg', 'image')
    # wechat_manager.get_temp_media('')
    # wechat_manager.upload_permanent_material(r'\changqiang.jpg', 'image')
    # wechat_manager.upload_image_for_article(r'\changqiang.jpg', )
    # wechat_manager.get_permanent_material('g_M2KtlphXosk-659uF4aiiXKa4f59mlmVcJAfN_yiagfIqzcerQ3gtPzMA8BLek')
    # wechat_manager.delete_permanent_material('g_M2KtlphXosk-659uF4aiiXKa4f59mlmVcJAfN_yiagfIqzcerQ3gtPzMA8BLek')
    # wechat_manager.get_material_count()
    # wechat_manager.get_material_list('news', count=1)

    # 示例文章内容
    articles = [
        {
            "title": "标题示例",
            "author": "作者示例",
            "digest": "摘要示例",
            "content": "<p>这是草稿的内容，支持HTML标签。</p>",
            # "content_source_url": "http://example.com",
            # "thumb_media_id": "YOUR_THUMB_MEDIA_ID",  # 替换为实际的封面图片素材ID
            "need_open_comment": 1,
            "only_fans_can_comment": 1,
            # "pic_crop_235_1": "0.1945_0_1_0.5236",
            # "pic_crop_1_1": "0.1_0_0.9_0.9"
        }
    ]

    # media_id = wechat_manager.add_draft(articles)
    # if media_id:
    #     print("新增草稿的媒体ID:", media_id)
    # print(wechat_manager.get_draft_count())
    # print(wechat_manager.get_draft_list(no_content=1))
    # wechat_manager.publish_draft("PG_DoQIYmKbkYxK8Cv6RNKEsfvjTh9KPkggHELDLw4LmznySIQhXI2gL4DgCswi1")
    # print(wechat_manager.get_publish_status("2247611752"))
    # print(wechat_manager.get_successful_publish_list(no_content=1))
    # print(wechat_manager.get_draft_list(count=20, no_content=1))
    print(wechat_manager.get_material_list("image"))